

void AXI_monitor_config();

void AXI_monitor_reset();

void AXI_monitor_stop();

void AXI_monitor_result();
