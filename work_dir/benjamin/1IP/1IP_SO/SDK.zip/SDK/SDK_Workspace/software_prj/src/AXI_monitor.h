

void AXI_monitor_configWR(int XPAR_AXI_MONITOR_BASEADDR);
void AXI_monitor_configRD(int XPAR_AXI_MONITOR_BASEADDR);

void AXI_monitor_reset(int XPAR_AXI_MONITOR_BASEADDR);

void AXI_monitor_stop(int XPAR_AXI_MONITOR_BASEADDR);

void AXI_monitor_result(int XPAR_AXI_MONITOR_BASEADDR);
