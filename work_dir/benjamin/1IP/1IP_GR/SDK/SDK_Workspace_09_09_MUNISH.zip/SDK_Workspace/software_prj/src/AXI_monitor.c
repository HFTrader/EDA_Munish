
#include "AXI_monitor.h"
#include "profile_cnt.h"
#include "xparameters.h"

char *monitor[]={"WRITE","READ"};

void AXI_monitor_config(int XPAR_AXI_MONITOR_BASEADDR)
{
printf("Monitoring Write transactions 1\r\n");
Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x300,0x00000002);

Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x44,0x01030002);
Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x48,0x00000000);
Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x4C,0x00000000);
//Xil_Out32(XPAR_AXI_PERF_MON_0_BASEADDR+0x48,0x00004042);
//Xil_Out32(XPAR_AXI_PERF_MON_0_BASEADDR+0x4C,0x0000E0E2);


	Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x30,0x00000001);
	Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x34,0x00000FFF);
	Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x24,0x00001000);
}


void AXI_monitor_reset(int XPAR_AXI_MONITOR_BASEADDR)
{
	  Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x300,0x00020002); //Reset of Global Cnt and Metric cnt
		  //  Xil_Out32(0x75C20028,0x00000002);
		  //  Xil_Out32(0x75C20028,0x00000001);
	Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x300,0x00010001); //Enable Global Cnt and Metric cnt

}

void AXI_monitor_stop(int XPAR_AXI_MONITOR_BASEADDR)
{
		Xil_Out32(XPAR_AXI_MONITOR_BASEADDR+0x300,0x00000000); //Disable Global Cnt and Metric cnt
		//	Xil_Out32(0x75C20028,0x0000000); //Disable the Down counter

}

void AXI_monitor_result(int XPAR_AXI_MONITOR_BASEADDR)
{ int i=0;
int test;

		printf("BUS clk cycles(143MHz): %u\r\n", (int)Xil_In32(XPAR_AXI_MONITOR_BASEADDR+0x4));
	    test= get_cyclecount();
	    printf("CPU clk cycles(667MHz): %d \n\r",test);

        
        printf("AXI_HP2:\r\n");
		printf("Bytes/Transactions:\r\n");
		//printf("%s \r\n",mode);
		for (i=0;i<2;i=i+1){
			printf("%s: %u/%u \r\n",monitor[i], (int)Xil_In32(XPAR_AXI_MONITOR_BASEADDR+0x100+16*(2*i)), (int)Xil_In32(XPAR_AXI_MONITOR_BASEADDR+0x100+16*((2*i)+1)));
			}
		for (i=0;i<=3;i++)
		{
	//	get_config_lvl_shifter();
	//	get_priority_AXI_HP(i);
	//	get_level_AXI_HP(i);
		//this register should only be read if a valid HP port clock is actively running. If not: will hang.
		}

xil_printf("-----------------------------------------------\n\r");

				//	printf("AXI exerciser reg master active bit value is:\r\n");
				//	printf("0x%08X : 0x%08X\r\n",XPAR_AXI_EXERCISER_0_BASEADDR, Xil_In32(XPAR_AXI_EXERCISER_0_BASEADDR));

/*	printf("AXI exerciser reg master active bit value is:\r\n");
	printf("0x%08X : 0x%08X\r\n",XPAR_AXI_EXERCISER_0_BASEADDR, Xil_In32(XPAR_AXI_EXERCISER_0_BASEADDR));
	printf("#######################################");
	printf("AXI exerciser Reg2_error active bit value is:\r\n");
		 	   	printf("0x%08X : 0x%08X\r\n",XPAR_AXI_EXERCISER_0_BASEADDR+0x08, Xil_In32(XPAR_AXI_EXERCISER_0_BASEADDR+0x08));
		 	    printf("######################################\r\n");
*/

}
