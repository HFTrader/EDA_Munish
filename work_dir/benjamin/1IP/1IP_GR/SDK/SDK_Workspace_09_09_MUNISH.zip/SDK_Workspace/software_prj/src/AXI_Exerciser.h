/*
 * AXI_Exerciser.h
 *
 *  Created on: Jun 12, 2014
 *      Author: ga46sam
 */

void AXI_Exerciser_config();
void AXI_Exerciser_start1();
void AXI_Exerciser_start2();
void AXI_Exerciser_clear();
void AXI_Exerciser_go();
void AXI_Exerciser_stop();

void mem_clean();
